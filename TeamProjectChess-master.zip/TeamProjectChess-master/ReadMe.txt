TO RUN:

1. Navigate to the TeamProjectChess/ directory (which this file is located in) on two different command lines.
2. On one command line, run ServerTest.bat.
3. Click Start to have the server start listening for clients.
4. On the other command line, run ClientconnectTest.bat.